=== Juiced Metrics===
Contributors: envisionyourwebsite.com
Donate link: http://www.envisionyourwebsite.com
Tags: Juiced Metrics, Sales Funnel, Conversion Funnels
Requires at least: 2.6
Tested up to: 3.9.1


Setup is simple You can create report names below. Select the pages you would like to track with the sales cycle or your sales funnel. Trackable pages can be created to follow how traffic is reacting to your sales funnels. This will show you which pages are working and which need modification. This will help you know what to work on to gain more sales.. . 

== Description ==

This plugin will allow you to place the shortcode 


if (function_exists('echo_views')) {echo_views(get_the_ID());}

on a WordPress front end theme single.php and page.php. 

*NEW: Manage your Juiced Metrics*

== Installation ==

1. Upload the `JuicedMetrics` directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. A new top-level menu called 'Juiced Metrics' will appear in your administration menu.
